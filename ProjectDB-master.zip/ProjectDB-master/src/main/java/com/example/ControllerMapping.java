package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
public class ControllerMapping {

    @Autowired
    private VehicleDAO vDB;

    @RequestMapping(value = "/postVehicle", method = RequestMethod.POST)
    public String addVehicle(@RequestBody Vehicle inVehicle) throws IOException {
        if (vDB.save(inVehicle))
            return "Success";
        else
            return "Vehicle already exists";
    }

    @RequestMapping(value = "/getVehicle/{id}", method = RequestMethod.GET)
    public Vehicle updateVehicle(@PathVariable("id") int id) throws IOException {
        Vehicle v = vDB.find(id);
        return v;
    }

    @RequestMapping(value = "/putVehicle", method = RequestMethod.PUT)
    public String updateVehicle(@RequestBody Vehicle inVehicle) throws IOException {
        if (vDB.update(inVehicle))
            return "Success";
        else
            return "Vehicle already exists";
    }

    @RequestMapping(value = "/deleteVehicle/{id}", method = RequestMethod.DELETE)
    public void deleteVehicle(@PathVariable("id") int id) throws IOException {
        vDB.delete(id);
    }
}
package com.example;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableScheduling
public class MyTasks {

    RestTemplate Template = new RestTemplate();

    @Scheduled(cron = "*/20 * * * * *")
    public void Delete() {
        Template.delete("http://localhost:8080/vehicle/2");
    }


    @Scheduled(cron = "*/20 * * * * *")
    public void SetVehicle() {
        Vehicle v = new Vehicle(2, 2010, 3400.5, "Toyota");
        HttpHeaders head = new HttpHeaders();
        head.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity ent = new HttpEntity(v, head);
        Template.exchange("http://localhost:8080/vehicle", HttpMethod.PUT, ent, String.class);
    }

    @Scheduled(cron = "*/20 * * * * *")
    public void CreateVehicle() {
        Vehicle v = new Vehicle(1995, 6987.4, "Honda");
        HttpHeaders head = new HttpHeaders();
        head.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity ent = new HttpEntity(v, head);
        Template.exchange("http://localhost:8080/vehicle", HttpMethod.POST, ent, String.class);
    }

    @Scheduled(cron = "*/20 * * * * *")
    public void GetVehicle() {
        Vehicle v = Template.getForObject("http://localhost:8080/vehicle/1", Vehicle.class);
        System.out.println(v.makeModel + " " + v.getId());
    }
}
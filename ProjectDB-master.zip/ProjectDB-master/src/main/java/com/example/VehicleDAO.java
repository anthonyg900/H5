package com.example;

        import org.springframework.stereotype.Repository;
        import javax.persistence.EntityManager;
        import javax.persistence.PersistenceContext;
        import javax.transaction.Transactional;

@Repository
@Transactional
public class VehicleDAO {

    @PersistenceContext
    private EntityManager em;

    public Vehicle find(int id) {
        return em.find(Vehicle.class, id);
    }

    public boolean update(Vehicle v){
        Vehicle vCheck = em.find(Vehicle.class, v.getId());
        if (vCheck == null) {
            System.out.println("Vehicle did not update");
            return false;
        } else {
            System.out.println("Vehicle Passed");
            em.merge(v);
            return true;
        }
    }

    public boolean save(Vehicle v){
        Vehicle vCheck = em.find(Vehicle.class, v.getId());
        if (vCheck != null) {
            System.out.println("Did not save");
            return false;
        } else {
            System.out.println("Vehicle Saved");
            em.merge(v);
            return true;
        }
    }

    public boolean delete(int id) {
        Vehicle v = em.find(Vehicle.class, id);
        if (v == null)
            return false;
        em.remove(v);
        return true;
    }

}

package com.example;
import javax.persistence.*;

@Entity
@Table(name = "toot")
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    public String makeModel;
    public int year;
    public double price;



    public Vehicle(int year, double price, String makeModel) {
        this.year = year;
        this.price = price;
        this.makeModel = makeModel;
    }

    public Vehicle(int id, int year, double price, String makeModel) {
        this.id = id;
        this.year = year;
        this.price = price;
        this.makeModel = makeModel;
    }

    public Vehicle() {
    }

    public int getId() {
        return this.id;
    }
}